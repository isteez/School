enum {
    red,
    blue
};