enum {
    empty, 
    filled
};