//
//  SubViewViewController.h
//  Pentago
//
//  Created by Stephen Kyles on 2/23/14.
//  Copyright (c) 2014 Stephen Kyles. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SubViewViewController : UIViewController <UIAlertViewDelegate>
-(id) initWithSubsquare: (int) position;
@end
