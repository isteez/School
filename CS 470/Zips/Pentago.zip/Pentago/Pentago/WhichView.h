enum {
    theGridView,
    theView
};