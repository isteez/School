#include "Set.hpp"

Set::Set( Player *p1, Player *p2 ): Competition( p1, p2 ) {}
Score *Set::play( Player *p ) {
    return 0;
}

